<?php
/**
 * Bablic Localization.
 *
 * LICENSE: This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @category  localization
 *
 * @author    Ishai Jaffe <ishai@bablic.com>
 * @copyright Bablic 2016
 * @license   http://www.gnu.org/licenses/ GNU License
 */

require_once 'sdk.php';
require_once 'store.php';

function startsWith($haystack, $needle)
{
    return $needle === '' || strrpos($haystack, $needle, -Tools::strlen($haystack)) !== false;
}
class Bablic extends Module
{
    private $_html = '';
    private $_postErrors = array();
    public function __construct()
    {
        $version_mask = explode('.', _PS_VERSION_, 3);
        $version_test = $version_mask[0] > 0 && $version_mask[1] > 3;
        $this->name = 'bablic';
        $this->tab = 'front_office_features'; //$version_test ? 'front_office_features' : 'Tools';
        $this->author = 'Ishai Jaffe';
        $this->version = '0.2.2';
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        $this->bootstrap = true;
        $this->module_key = '85b91d2e4c985df4f58cdc3beeaaa87d';
        parent::__construct();

        $this->displayName = $this->l('Bablic Localization');
        $this->description = $this->l('Connects your Prestashop to every language instantly');

        $controller = Tools::getValue('controller');
        $this->sdk = new BablicSDK(
            array(
              'channel_id' => 'prestashop',
              'store' => new BablicPrestashopStore(),
              'use_snippet_url' => true,
            )
        );

        if (startsWith($controller, 'Admin')) {
            return;
        }
        $this->sdk->handleRequest();
    }

    public function uninstall()
    {
        Configuration::updateValue('bablic_uninstalled', 'true');

        return true;
    }

    public function install()
    {
        parent::install();
        if (!$this->registerHook('displayHeader')) {
            return false;
        }
        if (!$this->registerHook('displayBackOfficeHeader')) {
            return false;
        }

        return true;
    }

    private function _postValidation()
    {
        if (!Validate::isCleanHtml(Tools::getValue('activate_bablic'))) {
            $this->_postErrors[] = $this->l('The message you entered was not allowed, sorry');
        }
    }

    private function siteCreate()
    {
        $rslt = $this->sdk->createSite(
            array(
                'site_url' => Tools::getHttpHost(true).__PS_BASE_URI__,
            )
        );

        return empty($rslt['error']);
    }

    private function _postProcess()
    {
        $data = Tools::jsonDecode(Tools::getValue('bablic_data'), true);
        $message = '';
        $error = '';
        $action = isset($data['action']) ? $data['action'] : '';
        switch ($action) {
            case 'create':
                $this->siteCreate();
                if (!$this->sdk->site_id) {
                    $error = 'There was a problem registering this site, please check that website is online and there is that Bablic snippet was not integrated before.';
                } else {
                    $message = 'Website was registered successfully';
                }
                break;
            case 'set':
                $site = $data['site'];
                $this->sdk->setSite($site);
                $message = '';
                break;
            case 'keep':
                Configuration::updateValue('bablic_uninstalled', '');
                break;
            case 'clear':
                Configuration::updateValue('bablic_uninstalled', '');
                $this->sdk->removeSite();
                break;
            case 'update':
                $this->sdk->refreshSite();
                break;
            case 'delete':
                $this->sdk->removeSite();
                $message = 'Website was deleted from Bablic';
                break;
        }
        $this->sdk->clearCache();
    }

    public function getContent()
    {
        $this->sdk->refreshSite();
        return $this->_displayForm();
    }

    private function _displayForm()
    {
        $fields_form[0]['form'] = array(
            'input' => array(
                array(
                    'type' => 'hidden',
                    'name' => 'bablic_raw_data',
                ),
                array(
                    'type' => 'hidden',
                    'name' => 'bablic_siteId',
                ),
                array(
                    'type' => 'hidden',
                    'name' => 'bablic_trial',
                ),
                array(
                    'type' => 'hidden',
                    'name' => 'bablic_editor',
                ),
                array(
                    'type' => 'hidden',
                    'name' => 'bablic_token',
                ),
                array(
                    'type' => 'hidden',
                    'name' => 'bablic_data',
                ),
                array(
                    'type' => 'hidden',
                    'name' => 'check',
                ),
            ),
        );
        $helper = new HelperForm();
        $helper->module = $this;
        $helper->title = $this->displayName;
        $helper->name_controller = 'bablic_container';
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
        if (empty($this->sdk->site_id)) {
            $was_installed = Configuration::get('bablic_uninstalled');
            if ($was_installed != '') {
                array_push($fields_form[0]['form']['array'], array(
                    'type' => 'hidden',
                    'name' => 'bablic_uninstalled',
                ));
                $helper->fields_value['bablic_uninstalled'] = $this->sdk->getMeta();
            }
        }
        $helper->fields_value['bablic_raw_data'] = $this->sdk->getMeta();
        $helper->fields_value['bablic_siteId'] = $this->sdk->site_id;
        $helper->fields_value['bablic_trial'] = $this->sdk->trial_started;
        $helper->fields_value['bablic_editor'] = $this->sdk->editorUrl();
        $helper->fields_value['bablic_token'] = $this->sdk->access_token;
        $helper->fields_value['bablic_data'] = '{}';
        $helper->fields_value['check'] = 'yes';

        return $helper->generateForm($fields_form);
    }

    public function hookdisplayHeader($params)
    {
        $alt_tags = $this->sdk->getAltTags();
        $this->context->smarty->assign('version', $this->version);
        $this->context->smarty->assign('locales', $alt_tags);
        $this->context->smarty->assign('snippet_url', $this->sdk->getSnippet());
        $this->context->smarty->assign('async', ($this->sdk->getLocale() == $this->sdk->getOriginal()));

        return $this->display(__FILE__, 'altTags.tpl');
    }

    public function hookDisplayBackOfficeHeader()
    {
//        $this->context->controller->addJS('//dev.bablic.com/js/sdk.js');
//        $this->context->controller->addJS('//dev.bablic.com/js/addons/prestashop.js');
//         $this->context->controller->addJS('//cdn2.bablic.com/addons/prestashop.js');
         $this->context->controller->addCSS('//cdn2.bablic.com/addons/prestashop.css');
    }
}
